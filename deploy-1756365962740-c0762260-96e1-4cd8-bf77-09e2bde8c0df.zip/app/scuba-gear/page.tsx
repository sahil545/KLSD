"use client";

import ScubaGear from "../../client/pages/ScubaGear";

export default function ScubaGearPage() {
  return <ScubaGear />;
}
